package fr.ceri.amiibo

data class AmiiboGameHeader(
    val amiibo: List<AmiiboGame>
)
