package fr.ceri.amiibo

data class AmiiboFull(
    val name: String,
    val gameSeries: String,
    val image: String
)