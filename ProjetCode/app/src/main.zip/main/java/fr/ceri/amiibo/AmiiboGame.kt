package fr.ceri.amiibo

data class AmiiboGame(
    val key: String,
    val name: String
)