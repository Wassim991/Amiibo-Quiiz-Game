package fr.ceri.amiibo

data class AmiiboHeader(
    val amiibo: List<AmiiboFull>
)
